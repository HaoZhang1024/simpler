# SWA 独立用例：A5 复测结论与证据

[返回索引](../README.zh-CN.md)

## 1. 结论与性能数据

**独立 SWA 在 A5 的 HBG、percounter 两条路线均跑通，所有轮次输出校验通过；构建和运行不调用 PyPTO／PTOAS。** 这份数据是后续 A6 迁移的 A5 基线，A6 尚未测试。

2026-11-17，设备 1，同一次单卡分配内先 HBG、后 percounter。每种调度 **1 次预热＋10 次 L0 正式测量**，全部正式样本计入均值。单位 ms：

| 调度 | 旧 PR AICore 均值 | 本次 AICore 均值 | 本次 AICore 最小～最大 | 本次 Device 均值 | 输出校验 |
| ---- | ----------------- | ---------------- | ---------------------- | ---------------- | -------- |
| HBG | 0.293834 | 0.267843 | 0.261352～0.272695 | 0.369469 | 11／11 轮通过 |
| percounter | 0.183123 | 0.185173 | 0.179372～0.192283 | 0.296698 | 11／11 轮通过 |

**可以确认：独立入口能执行原 SWA 任务并保留性能统计和校验。不能据此认定：用例精简带来了与旧表差值相等的加速。** 旧值来自 [原 PR 表](../../dsv41_scheduler/RESULTS.md)，运行时版本不同；本次核重新编译、组包，机器码和放置位置不保证与旧包相同。

| 指标 | 计时边界 |
| ---- | -------- |
| AICore L0 | 首个实际 AIC/AIV kernel 开始到最后一个结束，包含中间调度、依赖等待；不是各核耗时求和 |
| Device wall | 设备侧整次执行，另包含 AICPU 启动／收尾；不包含 Host 编译、输入加载、排队和输出拷回校验 |
| 整个测试进程 | 本次从 16:21:25 至 16:21:45（UTC+8），含初始化、输入恢复、校验等；约 20 秒不能当作 SWA 延迟 |

沿用原 PR 的 `production/timing.py` 严格端点统计器。逐轮结果见 [samples.csv](../results/2026-11-17-a5/samples.csv)，完整数值和指纹见 [summary.json](../results/2026-11-17-a5/summary.json)。

## 2. 提取改变了什么，验证覆盖到哪里

**精简的是编译与准备范围，SWA 的执行任务、输入和参考保持原有逻辑。**

| 项目 | 独立用例做法与保留内容 |
| ---- | ---------------------- |
| 核与编译 | 只编 SWA 的 19 个核，以及 native-runner、replay、record-tool；原计算 C++ 源码未修改 |
| 任务图 | 保留 16 个计算任务、578 个执行实例、依赖及 MIX／sync_start 设置 |
| 输入准备 | rank0 输入、原始 plan 元数据、参考输出打包约 104 KB，不含机器码；无需再次运行整网捕获和前缀 |
| 运行路径 | 复用生产 ChipWorker、HBG／percounter 和原 PR runner，执行原生 C++ 回放 |
| 输出校验 | 每轮恢复输入，对 30 个可写 Device buffer 按原规则逐字节比较；单字节参考按重复值比较 |
| 离线检查 | 输入长度／可写参考覆盖与损坏清单拒绝共 2 项通过；原统计器 7 项测试通过 |

原包包含 82 个核，独立包保留实际使用的 19 个；`callable.bin` 从 **2,971,352 字节变为 364,512 字节**。减少打包的核不等于减少 SWA 的执行实例。

plan 仍保存原捕获中的 Tensor 视图、别名和边界信息，replay 只提交 task 8～35；读取其他元数据不执行整网。它使用 `record.h/TensorData` 的二进制布局，迁移 A6 仍需核对或转换 ABI。

**正确性范围是这份零权重夹具与原参考的一致性。** 它不能替代真实权重精度测试，也不覆盖双卡 MoE／defer_wait。成功输出在内存中比较，未额外保存实际输出 buffer；输入、参考和校验日志均保留。

## 3. 环境、版本与执行记录

| 项目 | 本次记录 |
| ---- | -------- |
| 工作树 | `a6-migrate-case@4b2d9ca4b` 加用例目录新增脚本 |
| 本次运行时源码 | `26b0511f366c78534aed175c457c177ead4eb470`，本任务未修改运行时源码 |
| 旧 PR 表运行时源码 | `f1d91abdb80a1ea455e3239b4d060003170d693d` |
| 硬件／Host | Ascend950DT_9581，aarch64；单卡设备 1 |
| PTO-ISA | `83b1b2b52ded9ec5d91e02532a57cd95e497ba86` |
| CANN／编译器 | 安装标签 `cann-9.3.0`；`compiler/version.info` 实际报告 `9.2.0`；ccec 为 clang 15.0.5，原文见 summary |
| 构建打点 | `DFX=1`，`ORCH/SCHED/TENSORMAP_PROFILING=0` |
| 实际执行 | HBG `scheduler_mode=1`；percounter `scheduler_mode=5`；均为 `profiling=0` |
| 成功任务 | `task_20261117_162057_115609315149` |

环境记录保留组件实际版本，不能只根据 SDK 目录名判定。当前数据没有启用详细调度采集，L3 耗时未混入 L0。

| 尝试 | 结果与处理 | 证据 |
| ---- | ---------- | ---- |
| build-1 | 组包时中文路径被转义，文件读取失败；无设备执行 | [日志](../results/2026-11-17-a5/evidence/build-1.log.gz) |
| build-2 | 修正路径编码后重新构建成功 | [日志](../results/2026-11-17-a5/evidence/build-2.log.gz) |
| r001 | 队列自动追加 `--device`，CLI 尚未接受而退出；未执行 kernel | [任务日志](../results/2026-11-17-a5/evidence/r001-task.log.gz) |
| r002 | 补齐参数后两种调度均成功，表内样本全部来自此次 | [任务日志](../results/2026-11-17-a5/evidence/r002-task.log.gz) |

失败与成功记录均保留；失败尝试不作为性能样本。

## 4. 复现与证据位置

从仓库根目录按 [使用方法](usage.zh-CN.md) 加载 CANN、激活项目 `.venv` 并构建匹配运行时，再执行：

```bash
python -I tests/fdwic/a6_dsv41_scheduler/prepare.py build \
  --platform a5 --pto-isa build/pto-isa --jobs 4 \
  --build-dir tests/fdwic/a6_dsv41_scheduler/build/a5-retest

python -I tests/fdwic/a6_dsv41_scheduler/run.py \
  --build-dir tests/fdwic/a6_dsv41_scheduler/build/a5-retest \
  --output outputs/swa-a5-retest
```

构建和结果目录均使用新名字。输入来自 [随目录保存的夹具](../fixtures/fixture.json)，不依赖旧机器的输出目录；`run.py` 自动申请单卡，在分配内检查架构，再顺序测两种调度，编译不占设备。

| 材料 | 内容 |
| ---- | ---- |
| [samples.csv](../results/2026-11-17-a5/samples.csv) | 20 个正式样本的 AICore／Device 耗时 |
| [summary.json](../results/2026-11-17-a5/summary.json) | 运行条件、逐轮与汇总数值、校验规则、运行库／构建指纹、重试记录 |
| [evidence/](../results/2026-11-17-a5/evidence/) | 构建、任务、console、原生结果与 Host 端点日志，gzip 压缩 |
| [artifact-manifest.json](../results/2026-11-17-a5/artifact-manifest.json) | 归档文件清单、大小与校验和 |

归档日志将本机工作树／SDK 路径替换为变量；原始本地日志保留在 `outputs/a6-swa-baseline/`。本次只采 L0，未生成详细泳道图；需要调度分析时另采 L3。
